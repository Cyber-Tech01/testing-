function toggle() {
  let menu = document.getElementById('menu-over');
  
  let menubtn = document.getElementById('menu-btn');
  
  if(menu.classList.contains("show")) {
    menu.classList.remove("show");
    menubtn.innerHTML = "☰ Menu"
  } else {
    menu.classList.add("show");
    menubtn.innerHTML = "✖ Close"
  }
  
}

// Search 

document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("search-input");
  const searchBtn = document.getElementById("search-btn");
  const articles = document.querySelectorAll(".sec1"); // Ensure your blog posts have this class

  function searchArticles() {
    let searchText = searchInput.value.toLowerCase();

    articles.forEach(article => {
      let title = article.querySelector("h2").textContent.toLowerCase();

      if (title.includes(searchText)) {
        article.style.display = "block";
        article.style.color = "red"
      } else {
        article.style.display = "none";
      }
    });
  }

  searchBtn.addEventListener("click", searchArticles);

  // Also trigger search on pressing "Enter" in the input field
  searchInput.addEventListener("keyup", function (event) {
    if (event.key === "Enter") {
      searchArticles();
    }
  });
});

//comments

//COMMENT SECTION 😂 👇
function loadComments() {
  let commentsData = localStorage.getItem("comments");
  let savedComments = commentsData ? JSON.parse(commentsData) : [];

  if (!Array.isArray(savedComments)) {
    savedComments = [];  // Ensure it's always an array
  }

  let commentSection = document.getElementById("commentSection");
  commentSection.innerHTML = "";

  savedComments.forEach((comment, index) => {
    let commentBox = document.createElement("div");
    commentBox.className = "comment-box";

    commentBox.innerHTML = `
        <p><strong>${comment.username}</strong></p>
        <p>${comment.text}</p>
        <p class="comment-meta">${comment.timestamp}</p>
        <span class="like-btn" onclick="likeComment(${index})">
            <i class="fa-regular fa-thumbs-up"></i> ${comment.likes}
        </span>
        <span class="delete-btn" onclick="deleteComment(${index})">
            <i class="fa-solid fa-trash"></i>
        </span>
    `;

    commentSection.appendChild(commentBox);
  });
}

function addComment() {
  let username = document.getElementById("username").value.trim();
  let commentText = document.getElementById("commentInput").value.trim();

  if (username !== "" && commentText !== "") {
    let commentsData = localStorage.getItem("comments");
    let savedComments = commentsData ? JSON.parse(commentsData) : [];

    if (!Array.isArray(savedComments)) {
      savedComments = [];
    }

    let newComment = {
      username: username,
      text: commentText,
      timestamp: new Date().toLocaleString(),
      likes: 0
    };

    savedComments.push(newComment);
    localStorage.setItem("comments", JSON.stringify(savedComments));

    loadComments();

    document.getElementById("username").value = "";
    document.getElementById("commentInput").value = "";
  }
}

function likeComment(index) {
  let commentsData = localStorage.getItem("comments");
  let savedComments = commentsData ? JSON.parse(commentsData) : [];

  if (!Array.isArray(savedComments)) {
    savedComments = [];
  }

  savedComments[index].likes += 1;
  localStorage.setItem("comments", JSON.stringify(savedComments));
  loadComments();
}
/*
function deleteComment(index) {
  let commentsData = localStorage.getItem("comments");
  let savedComments = commentsData ? JSON.parse(commentsData) : [];

  if (!Array.isArray(savedComments)) {
    savedComments = [];
  }

  savedComments.splice(index, 1);
  localStorage.setItem("comments", JSON.stringify(savedComments));
  loadComments();
}
*/

window.onload = loadComments;